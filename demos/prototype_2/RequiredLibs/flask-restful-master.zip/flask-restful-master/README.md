# Flask-RESTful

[![Build Status](https://travis-ci.org/twilio/flask-restful.svg?branch=master)](http://travis-ci.org/twilio/flask-restful)

Flask-RESTful provides the building blocks for creating a great REST API.

## User Guide

You'll find the user guide and all documentation [here](http://flask-restful.readthedocs.org/en/latest/)

