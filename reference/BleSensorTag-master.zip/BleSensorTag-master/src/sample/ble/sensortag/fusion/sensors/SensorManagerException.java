package sample.ble.sensortag.fusion.sensors;

public class SensorManagerException extends IllegalStateException {
}
